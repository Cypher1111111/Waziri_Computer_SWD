<center>
		<footer>
		
		<p>WUFPBK E-Learning Copyright @CypherTech 2024</p>
			<!-- <p>Programmed by: CypherTech</p> -->
		</footer>
</center>

