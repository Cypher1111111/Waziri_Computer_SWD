<div class="pull-right">
		<footer>
           <p>Programmed by: CypherTech</p>
        <footer>
</div>