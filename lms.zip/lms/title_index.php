				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/Logo.jpeg">
						</div>	
						<div class="span8">
						
								<div class="title">
							<h5 class="WUFPBK">WAZIRI UMARU FEDERAL POLYTECHNIC BRININ KEBBI </h5>
							<h3>

							<p>E - Learning</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>WUFPBK EXCELS:</p>
												<p>Excellence, Competence and Educational</p>
												<p>Leadership in Science and Technology</p>
								</div>		
						</div>		
				</div>